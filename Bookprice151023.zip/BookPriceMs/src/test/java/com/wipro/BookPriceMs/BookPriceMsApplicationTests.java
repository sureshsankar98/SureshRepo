package com.wipro.BookPriceMs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookPriceMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
