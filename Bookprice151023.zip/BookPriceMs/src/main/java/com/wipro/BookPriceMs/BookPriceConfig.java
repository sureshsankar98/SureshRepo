package com.wipro.BookPriceMs;

public class BookPriceConfig {

}
