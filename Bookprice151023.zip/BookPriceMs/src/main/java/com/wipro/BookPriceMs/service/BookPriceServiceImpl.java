package com.wipro.BookPriceMs.service;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wipro.BookPriceMs.dao.BookPriceDao;
import com.wipro.BookPriceMs.entity.BookPrice;

@Service
@Transactional

public class BookPriceServiceImpl implements BookPriceService {
	
	static {

		System.out.println("BookPriceImpl");
		
	}
	static Logger log = LoggerFactory.getLogger(BookPriceServiceImpl.class);
	@Autowired
	BookPriceDao bookPriceDAO;

	@Override
	public double getOfferedPriceById(Integer bookId) {

		log.info("---BookPriceServiceImpl---getOfferedPriceById()-----");
		double offerPrice = 0.0;
		Optional<BookPrice> opt = bookPriceDAO.findById(bookId);
		if (opt.isPresent()) {
			BookPrice bookPrice = opt.get();
			double price = bookPrice.getPrice();
			double offer = bookPrice.getOffer();

			if (offer <= 0) {
				return price;
			}
			offerPrice = price - price * offer / 100;
		}
		return offerPrice;
	}

	@Override
	public BookPrice getBookPriceById(Integer bookId) {
		log.info("---BookPriceServiceImpl---getBookPriceById()-----");
		BookPrice bookPrice = null;
		Optional<BookPrice> opt = bookPriceDAO.findById(bookId);
		if (opt.isPresent()) {
			bookPrice = opt.get();
		}
		return bookPrice;
	}

}
