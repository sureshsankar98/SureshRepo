package com.wipro.BookPriceMs.service;

import com.wipro.BookPriceMs.entity.BookPrice;

public interface BookPriceService {
	public BookPrice getBookPriceById(Integer bookId);
	public double getOfferedPriceById(Integer bookId);

}
