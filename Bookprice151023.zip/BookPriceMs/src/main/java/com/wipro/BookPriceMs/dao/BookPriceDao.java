package com.wipro.BookPriceMs.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.wipro.BookPriceMs.entity.BookPrice;


public interface BookPriceDao extends JpaRepository<BookPrice, Integer> {

}
